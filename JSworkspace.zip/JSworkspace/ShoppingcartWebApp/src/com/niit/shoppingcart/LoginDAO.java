package com.niit.shoppingcart;

public class LoginDAO {

	public boolean isValidUser(String user, String pswd)
	{
		if (user.equals(pswd))
			
		{
			
			return(true);
		}
		else
		{
			
			return(false);
		}
	}
}
