package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.ProductDAO;
import com.niit.shopingcart.model.Product;




public class ProductTest {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		
		Product product = (Product) context.getBean("product");
		
		product.setId("PR111");
		product.setName("PROName111");
		product.setDescription("PROdesc111");
//		product.setdescription("PRODesc111");
		
		
		productDAO.saveOrUpdate(product);
		
		if (productDAO.get("hgdf") == null)
		{
			System.out.println("Product doesn't exist");
		}
		else
		{
			System.out.println("Product exists");
			System.out.println();
		}
	}

}
