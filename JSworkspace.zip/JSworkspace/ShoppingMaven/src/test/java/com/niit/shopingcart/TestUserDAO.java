package com.niit.shopingcart;
/*
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.UserDAO;
import com.niit.shopingcart.model.UserDetails;

public class TestUserDAO {

//	@Autowired
//	UserDAO userDAO;
//	@Autowired
//	UserDetails userDetails;
//
//	AnnotationConfigApplicationContext context;
//
//	@Before
//	public void init() {
//		context = new AnnotationConfigApplicationContext();
//		context.scan("com.niit");
//		context.refresh();
//
//		userDAO = (UserDAO) context.getBean("userDAO");
//		userDetails = (UserDetails) context.getBean("userDetails");
//	}
//
//	@Test
//	public void UsersTestCase() {
//		int size = userDAO.list().size();
//		assertEquals("User list Test Case", 2, size);
//	}

}
*/