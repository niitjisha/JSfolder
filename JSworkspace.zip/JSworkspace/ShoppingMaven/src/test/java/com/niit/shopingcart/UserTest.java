package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.UserDAO;
import com.niit.shopingcart.model.User;



public class UserTest {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");
		
		user.setId("U101");
		user.setName("Rakesh");
		user.setPswd("Raku");;
		user.setMob(35876521);;
		user.setMail("Rak@gmail.com");;
		user.setAddress("Malleshwaram");
		
		
		userDAO.saveOrUpdate(user);
		
		if (userDAO.get("hgdf") == null)
		{
			System.out.println("User doesn't exist");
		}
		else
		{
			System.out.println("User exists");
			System.out.println();
		}
	}

}
