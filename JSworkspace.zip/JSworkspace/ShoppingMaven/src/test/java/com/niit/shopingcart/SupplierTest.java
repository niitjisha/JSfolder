package com.niit.shopingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.SupplierDAO;
import com.niit.shopingcart.model.Supplier;



public class SupplierTest {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		
		Supplier supplier = (Supplier) context.getBean("supplier");
		
		supplier.setId("SUP111");
		supplier.setName("SUPName111");
		supplier.setAddress("SUPaddr111");
		
		
		supplierDAO.saveOrUpdate(supplier);
		
		if (supplierDAO.get("hgdf") == null)
		{
			System.out.println("Supplier doesn't exist");
		}
		else
		{
			System.out.println("Supplier exists");
			System.out.println();
		}
	}

}
