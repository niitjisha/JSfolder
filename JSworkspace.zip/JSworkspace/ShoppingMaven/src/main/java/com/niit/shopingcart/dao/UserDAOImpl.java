package com.niit.shopingcart.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shopingcart.model.User;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO{

	
		
		@Autowired
		
		private SessionFactory sessionFactory;
		
		public UserDAOImpl(SessionFactory sessionFactory)
		{
			this.sessionFactory=sessionFactory;
		}
		
		
		@Transactional
		public void saveOrUpdate(User user) {
			sessionFactory.getCurrentSession().saveOrUpdate(user);		
		}
		
		@Transactional
		public void Delete(String id)
		{
			User user = new User();
			user.setId(id);
			sessionFactory.getCurrentSession().delete(user);
		}
		
		@Transactional
		public User get(String id)
		{
			String hql = "from User where id = "+"'"+id+"'";
			//from User where id='101'
			
			@SuppressWarnings("rawtypes")
			Query query = (Query)sessionFactory.getCurrentSession().createQuery(hql);
			@SuppressWarnings("unchecked")
			List<User> listUser = (List<User>) query.getResultList();
			
			if (listUser != null & !listUser.isEmpty())
			{
				return listUser.get(0);
			}
			return null;
		}
		
		
		@SuppressWarnings("rawtypes")
		@Transactional
		public boolean isValidUser(String name, String password)
		{
			String hql = " from User where uid = '" +name+ "'" + "and upswd = '" +password+ "'";
			Query q = sessionFactory.getCurrentSession().createQuery(hql);
			@SuppressWarnings("deprecation")
			//List list = q.list();
			List<User> listUser = q.getResultList();
			if (listUser == null || listUser.isEmpty())
			{
				return false;
			}
			else
			{
				System.out.println("TRUE");
				return true;
			}
		}
		
		@Transactional
		public List<User> list()
		{
			@SuppressWarnings({ "unchecked", "deprecation" })
			List<User> listUser =(List<User>) 
				sessionFactory.getCurrentSession()
				.createCriteria(User.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
			return listUser;
		}
		
		
		
}
