package com.niit.ecart;

public class TestCategory {

	public static void main(String[] args) {
		
		Category category = new Category();
		
		category.setId("1");
		category.setName("internet");
		category.setDesc("for connection");
		
		System.out.println( category.getId());
		System.out.println( category.getName());
		System.out.println(category.getDesc());
		
	}

}
