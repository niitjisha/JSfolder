package com.niit.shopingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shopingcart.dao.UserDAO;


@Controller
public class UserController {
	@Autowired
	private UserDAO userDAO;

	
	@RequestMapping("/")
	public String getLanding() {
		System.out.println("Landing page is Loaded.....");
		return "index";
	}

	@RequestMapping("/Home")
	public String getHome() {
		System.out.println("Home page is Loaded.....");
		return "Home";
	}

	@RequestMapping("/Contact")
	public String getContact() {
		System.out.println("Contact page is Loaded.....");
		return "Contact";
	}

	@RequestMapping("/About")
	public String getAbout() {
		System.out.println("About page is Loaded.....");
		return "About";
	}

	@RequestMapping("/SignUp")
	public String getSignUp() {
		System.out.println("SignUp page is Loaded.....");
		return "SignUp";
	}

	@RequestMapping("/Login")
	public String getLogin() {
		System.out.println("Login page is Loaded.....");
		return "Login";
	}

	@RequestMapping("/Check")
	public ModelAndView login(@RequestParam(name = "name") String name,@RequestParam(name = "pswd") String password) 
	{
		ModelAndView mv;

		boolean isValidUser = userDAO.isValidUser(name, password);
		
		if (isValidUser) {
			mv = new ModelAndView("/Admin");
			mv.addObject("message","Valid User");
		}
		else
		{
			mv= new ModelAndView("/Fail");
			mv.addObject("message", "Invalid User");
		}
		return mv;
	}
	
	/*
	 * public String getLogin() {
	 * System.out.println("Login page is Loaded....."); return "/Test"; }
	 */
	/*
	 * @RequestMapping("/Login") public String getLogin() {
	 * System.out.println("Login page is Loaded....."); return "Login"; }
	 */
}
