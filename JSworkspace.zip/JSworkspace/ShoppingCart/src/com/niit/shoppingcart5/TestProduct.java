package com.niit.shoppingcart5;

public class TestProduct {

	public static void main(String[] args) {
		
		Product p1 = new Product("PR001", "HP Laptop");
		Product p2 = new Product("PR002", "Samsung note5", 40000.0);
		
		p1.setPrice(-15000);
		
		System.out.println( p1.getId()  );
		System.out.println(p1.getName());
		System.out.println(p1.getPrice());
		
		System.out.println( p2.getId()  );
		System.out.println(p2.getName());
		System.out.println(p2.getPrice());


	}

}
