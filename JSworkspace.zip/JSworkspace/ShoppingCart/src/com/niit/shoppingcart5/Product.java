package com.niit.shoppingcart5;

public class Product {

	private String id;
	private String name;
	private double price;
	
	
	
	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}
	

	
	public void setPrice(double price) {
		if (price < 0)
		{
			System.out.println("Price cannot be negative");
			this.price = 500;
		}
		
	}

	
	public Product(String id, String name)
	{
		this.id = id;
		this.name = name;
	}
	
	public Product(String id, String name,double price)
	{
		this.id = id;
		this.name = name;
		this.price = price;
	}
}

