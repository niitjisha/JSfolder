package com.niit.shoppingcart;

public class TestProduct {

	public static void main(String[] args) {
		Product product = new Product();
		
		product.setId("PR1");
		product.setName("Photon");
		product.setPrice(3000);
		
		System.out.println(  product.getId());
		System.out.println(  product.getName());
		System.out.println(  product.getPrice());
	}

}
