package com.niit.shoppingcart;

import com.niit.ecart.Category;


public class TestProduct {

	public static void main(String[] args) {
		Product product = new Product();
		
		product.setId("PR1");
		product.setName("Photon");
		product.setPrice(3000);
		
		System.out.println(  product.getId());
		System.out.println(  product.getName());
		System.out.println(  product.getPrice());
		
		
		
		Category category = new Category();
		
		category.setId("2");
		category.setName("connection");
		category.setDesc("for internet");
		
		System.out.println( category.getId());
		System.out.println( category.getName());
		System.out.println(category.getDesc());
		
	}

}
