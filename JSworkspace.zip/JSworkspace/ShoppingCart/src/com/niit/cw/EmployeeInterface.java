package com.niit.cw;

public interface EmployeeInterface {

	
		public void acceptEmployee();
		public void displayEmployee();
		
	
	
	
}
