package com.niit.cw;

public abstract class StudentInfo {

		abstract void acceptStudent();
		abstract void displayStudent();
		
		void addStudent()
		{
			int newId;
			String newName;
			
			newId = 200;
			
			System.out.println(newId);
		}

}