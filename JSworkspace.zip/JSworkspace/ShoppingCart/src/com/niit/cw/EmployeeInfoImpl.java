package com.niit.cw;

public class EmployeeInfoImpl implements EmployeeInterface
{
	int id;
	String name;
	public void acceptEmployee()
	{
		id=201;
		name="RAHUL";
		
	}
	
	public void displayEmployee()
	{
		System.out.println("Student id is:"+id);
		System.out.println("Student name is:"+name);
	}


	public static void main(String args[])
	{
		
		
		EmployeeInterface ei = new EmployeeInfoImpl();
		ei.acceptEmployee();
		ei.displayEmployee();
		
//		sf.acceptStudent();
//		sf.displayStudent();
	}
}
