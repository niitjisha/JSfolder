package com.niit.cw;

public class StudentInfoImpl extends StudentInfo
{
	int id;
	String name;
	void acceptStudent()
	{
		id=201;
		name="RAHUL";
		
	}
	
	void displayStudent()
	{
		System.out.println("Student id is:"+id);
		System.out.println("Student name is:"+name);
	}


	public static void main(String args[])
	{
		StudentInfoImpl si = new StudentInfoImpl();
		si.acceptStudent();
		si.displayStudent();
		StudentInfo sf = new StudentInfoImpl();
		sf.acceptStudent();
		sf.displayStudent();
	}
}

