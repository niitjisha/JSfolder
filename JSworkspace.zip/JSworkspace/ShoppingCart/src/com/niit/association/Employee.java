package com.niit.association;

public class Employee {
	private int id;
	private String name;
	
	private Employee manager;
	private Department dept;
	
	
	
	
	
	
	

	public Employee getManager() {
		return manager;
	}








	public void setManager(Employee manager) {
		this.manager = manager;
	}








	public Department getDept() {
		return dept;
	}








	public void setDept(Department dept) {
		this.dept = dept;
	}








	public Employee(int id, String name) {
		
		this.id = id;
		this.name = name;
	}








	public static void main(String[] args) {
		
		Employee manager = new Employee(111, "Nijil");
		Employee clerk = new Employee(112, "Rohit");
		
		clerk.setManager(manager);
		
		Department office = new Department(10,"IT");
		
		clerk.setDept(office);
		
		manager.setDept(office);
		
		//Department office1 = new Department(10,"IT");
		
		
		
		displayC(clerk);
		
		
		
		displayM(manager);
		

	}








	public int getId() {
		return id;
	}








	public String getName() {
		return name;
	}








	private static void displayC(Employee clerk) {
		System.out.println(clerk.getId());
		System.out.println(clerk.getDept().getDname());
		
		
	}
	
	private static void displayM(Employee manager) {
		System.out.println(manager.getDept().getDname());
		
	}

}
