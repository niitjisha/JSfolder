package com.niit.association;

public class Department {

	private int did;
	private String dname;
	
	public Department(int did, String dname) {
		
		this.did = did;
		this.dname = dname;
	}

	public int getDid() {
		return did;
	}

	public String getDname() {
		return dname;
	}
	
	
	
}
