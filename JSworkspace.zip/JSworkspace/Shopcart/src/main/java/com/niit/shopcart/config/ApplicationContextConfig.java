package com.niit.shopcart.config;

public class ApplicationContextConfig {

}
