package com.niit.shopingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController 
{
	@RequestMapping("/")
	public String getLanding()
	{
		System.out.println("Landing page is Loaded.....");
		return "index";
	}
	
	@RequestMapping("/Home")
	public String getHome()
	{
		System.out.println("Home page is Loaded.....");
		return "Home";
	}
	
	@RequestMapping("/Contact")
	public String getContact()
	{
		System.out.println("Contact page is Loaded.....");
		return "Contact";
	}
	
	@RequestMapping("/About")
	public String getAbout()
	{
		System.out.println("About page is Loaded.....");
		return "About";
	}
	
	@RequestMapping("/SignUp")
	public String getSignUp()
	{
		System.out.println("SignUp page is Loaded.....");
		return "SignUp";
	}
	
	@RequestMapping("/Login")
	public String getLogin()
	{
		System.out.println("Login page is Loaded.....");
		return "Login";
	}
}
